# Power_BI_-E-Commerce
# Using Power BI to create a report for an E-Commerce business
